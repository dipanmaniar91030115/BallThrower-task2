﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : Singleton<Player>
{
    public GameObject BallPrefab;
    public Vector3 BallOffset = new Vector3(0.5f, 0.5f, 0.5f); // offset from camera to create balls when throwing
    public int Score { get { return score; } }

    public int score;
    public int pooledAmount = 100;
    List<GameObject> balls;



    // Use this for initialization
    void Start()
    {
        score = 0;
        // Creating all instances of the balls at the start
        balls = new List<GameObject>();
        for (int i = 0; i < pooledAmount; i++)
        {
            GameObject obj = (GameObject)Instantiate(BallPrefab);

            // Setting them inactive until they are needed
            obj.SetActive(false);

            // adding the object to the balls list
            balls.Add(obj);

        }
    }

    void FixedUpdate()
    {
        if (Time.frameCount % 2 == 0) // throw a ball every 2nd update
            ThrowBall();
    }

    private void ThrowBall()
    {
        // throw ball
        GameObject newBall = (GameObject)GameObject.Instantiate(BallPrefab, this.transform.position + BallOffset, this.transform.rotation);
        // add some randomness to throw vector
        Vector3 randVec = Random.insideUnitSphere;
        randVec.y *= 0.1f;
        // combine basic throw vector with randomness
        Vector3 throwVector = (new Vector3(-2f, 0.2f, 0f) + randVec) * 1400f;
        newBall.GetComponent<Rigidbody>().AddForce(throwVector);

        // searching for the first inactive ball prefab so it can be used/recycled
        for (int i = 0; i < balls.Count; i++)
        {

            // Finding the first ball in the object pool that is not in use
            if (!balls[i].activeInHierarchy)
            {
                balls[i].transform.position = transform.position;
                balls[i].transform.rotation = transform.rotation;
                balls[i].SetActive(true);

                break;

            }

        }

    }

    public void IncreaseScore(int scoreChange)
    {
        score += scoreChange;
    }
}
