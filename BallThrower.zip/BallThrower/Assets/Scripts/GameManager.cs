﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{

    private float maxTimeSeconds = 10 * 60;

    public float MaxTimeSeconds
    {
        get { return maxTimeSeconds; }
        set { maxTimeSeconds = value; }

    }

    private float timePassed;

    public float TimePassed
    {
        get { return timePassed; }
        set { timePassed = value; }
    }

    private int score;

    public int Score
    {
        get { return score; }
        set { score = value; }
    }


    private int playerLevel;

    public int PlayerLevel
    {
        get { return playerLevel; }
        set { playerLevel = value; }
    }


    void Start()
    {
        TimePassed = 0;
        Score = 0;
        PlayerLevel = 0;
    }

    void Update()
    {
        TimePassed += Time.deltaTime;
        Score = Player.Instance.Score;

        // Setting player level based on the score variable
        PlayerLevel = Score / 1000;

        if (TimePassed >= maxTimeSeconds)
        {
            // resetting the scene when it reaches the maximum time
            TimePassed = 0;
            Player.Instance.score = 0;
            PlayerLevel = 0;
            SceneManager.LoadScene(0);
        }



    }
}


