﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpdateUI : MonoBehaviour
{

    [SerializeField]
    private Text timerLabel;

    [SerializeField]
    private Text scoreLabel;

    [SerializeField]
    private Text playerLevelLabel;




    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        // accesing the text variables on the canvas then setting them to the desired text
        timerLabel.text = "Time: " + FormatTime(GameManager.Instance.TimePassed);
        scoreLabel.text = "Score: " + Player.Instance.Score.ToString();
        playerLevelLabel.text = "Player Level: " + GameManager.Instance.PlayerLevel;
    }

    private string FormatTime(float timeInSeconds)
    {
        // Formatting time s o it displays properly
        return string.Format("{0}:{1:00}", Mathf.FloorToInt(timeInSeconds / 60), Mathf.FloorToInt(timeInSeconds % 60));
    }


}
